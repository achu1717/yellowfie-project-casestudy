import React, { useState } from "react";
import { View, StyleSheet, Button, Alert, Text } from "react-native";

  const ButtonAlert =( props) =>{
    const[alertq,setAlert]=useState({title1:"ORDER",msg:"hi"})
    const ButtonAlertMsg =() =>{
      Alert.alert(
        alertq.title1,
         alertq.msg,
         [
           { text: "No", onPress: () => console.log("NO") },
           {
             text: "Yes",
             onPress: () => console.log("YES"),
             style: "cancel"
           }
         ],
         { cancelable: false }
       );
     }
    

  

  return (
    <View style={styles.container}>
      <Button title={"click"} onPress={ButtonAlertMsg} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "space-around",
    alignItems: "center"
  }
});

export default ButtonAlert;