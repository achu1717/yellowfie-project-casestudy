import React, { useState } from "react";
import { View, StyleSheet, Button, Alert, Text } from "react-native";
import ButtonAlert from "./Chat"
 export const ButtonAlertData = (props) => {
    const[alertq,setAlert]=useState([{title1:"ORDER",msg:"hi"}])
    
    

  

  return (
    <View style={styles.container}>
      <ButtonAlertData data={alertq}/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "space-around",
    alignItems: "center"
  }
});

